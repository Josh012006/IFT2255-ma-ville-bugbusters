package ca.udem.maville;

import ca.udem.maville.client.Signalement;
import org.junit.jupiter.api.Test;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 
 * Ces tests valident les comportements attendus lors de la manipulation des signalements :
 * - gestion de collection (HashMap),
 * - gestion d'erreurs lors de la création (description vide),
 * - comportement de représentation (toString).
 */
public class SignalementTest {

    /**
     * Test 1 — Remplacement dans la HashMap :
     * Vérifie que lorsqu'un signalement avec un identifiant identique est ajouté dans une HashMap,
     * il écrase l'ancien. Résultat attendu : la taille de la HashMap reste à 1.
     */
    @Test
    public void testAjoutSignalementDansMap() {
        Signalement s1 = new Signalement("Type", "Loc", "Desc", "res1", "Plateau", "sig1");
        Signalement s2 = new Signalement("Type", "Loc", "Desc", "res1", "Plateau", "sig1");
        HashMap<String, Signalement> map = new HashMap<>();
        map.put("sig1", s1);
        map.put("sig1", s2);
        assertEquals(1, map.size());
    }

    /**
     * Test 2 — Création invalide (description vide) :
     * Vérifie qu’un signalement avec une description vide lance une IllegalArgumentException.
     * Résultat attendu : exception levée.
     */
    @Test
    public void testSignalementDescriptionInvalide() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Signalement("X", "Y", "", "res1", "Rosemont", "sig2");
        });
    }

    /**
     * Test 3 — Représentation correcte (toString) :
     * Vérifie que la méthode toString retourne une valeur non nulle.
     * Résultat attendu : toString() ≠ null.
     */
    @Test
    public void testToStringNonNul() {
        Signalement s = new Signalement("X", "Y", "desc", "res1", "Rosemont", "sig3");
        assertNotNull(s.toString());
    }
}
