package ca.udem.maville;

import ca.udem.maville.client.FicheProbleme;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FicheProblemeTest {

    FicheProbleme fiche;

    @BeforeEach
    void setUp() {
        fiche = new FicheProbleme("123", "Voirie", "123 rue", "Desc", 2, "Plateau");
    }

    /**
     * Vérifie que l’ajout d’un signalement fonctionne sans dépasser l’index.
     * Résultat attendu : exception si on accède à un index inexistant.
     */
    @Test
    void testAjoutSignalement() {
        fiche.addSignalement("SIG001");
        assertThrows(IndexOutOfBoundsException.class, () -> {
            fiche.getSignalements().get(1);
        });
    }

    /**
     * Vérifie que le résident ajouté est bien dans la liste.
     * Résultat attendu : "RES001" présent dans les résidents.
     */
    @Test
    void testAjoutResident() {
        fiche.addResident("RES001");
        assertTrue(fiche.getResidents().contains("RES001"));
    }
}

    
