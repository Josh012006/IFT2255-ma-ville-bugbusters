package ca.udem.maville;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @Test
    public void testsAreWorking() {
        assertTrue(true);
    }

    
    /**
     * Test  — Clé unique :
     * Vérifie que deux appels successifs à la méthode generateID produisent des chaînes différentes.
     * Résultat attendu : deux identifiants uniques.
     */
    @Test
    public void testUniqueIDGeneration() {
        String id1 = java.util.UUID.randomUUID().toString();
        String id2 = java.util.UUID.randomUUID().toString();
        assertNotEquals(id1, id2);
    }
}