package ca.udem.maville;

import ca.udem.maville.client.users.Resident;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests unitaires pour la classe Resident
 */
public class ResidentTest {

    Resident r;

    @BeforeEach
    void init() {

        // Créer une date de naissance (par exemple : 1er janvier 2000)
        Calendar cal = Calendar.getInstance();
        cal.set(2000, Calendar.JANUARY, 1);
        Date dateNaissance = cal.getTime();
        // Initialisation avec les bons paramètres requis par le constructeur
        r = new Resident("RES001", "Jean Dupont", "jean@example.com", "123 rue Ontario", "H2X 1Y4", "Plateau", dateNaissance);
    }

    /**
     * Test 1 — Ajout de signalement :
     * Vérifie que l'ajout d'un signalement fonctionne correctement.
     * Résultat attendu : le signalement "SIG001" est présent dans la liste.
     */
    @Test
    void testAjoutSignalement() {
        r.addSignalement("SIG001");
        assertTrue(r.getSignalements().contains("SIG001"));
    }

    /**
     * Test 2 — Liste de notifications vide :
     * Vérifie que la liste des notifications est vide par défaut.
     * Résultat attendu : getNotifications().isEmpty() == true
     */
    @Test
    void testDefaultNotificationsEmpty() {
        assertTrue(r.getNotifications().isEmpty());
    }

    /**
     * Test 3 — Récupération de l’ID :
     * Vérifie que l'identifiant est bien stocké.
     * Résultat attendu : "RES001".
     */
    @Test
    void testGetId() {
        assertEquals("RES001", r.getID());
    }
}
