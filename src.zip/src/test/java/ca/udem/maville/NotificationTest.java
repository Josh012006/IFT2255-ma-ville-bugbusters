package ca.udem.maville;

import ca.udem.maville.client.users.Notification;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class NotificationTest {

    /**
     * Vérifie que la méthode toString() ne retourne pas null.
     * Résultat attendu : une chaîne non nulle est produite.
     */
    @Test
    void testNotificationNonNulle() {
        Notification n = new Notification("Un message", "notif1");
        assertNotNull(n.toString());
    }

    /**
     * Vérifie que le message est présent dans la représentation textuelle.
     * Résultat attendu : "Erreur" est présent dans la chaîne.
     */
    @Test
    void testToStringContainsMessage() {
        Notification n = new Notification("Erreur importante", "notif2");
        assertTrue(n.toString().contains("Erreur"));
    }

    /**
     * Vérifie que l'identifiant est bien dans la chaîne toString().
     * Résultat attendu : "notif3" est mentionné.
     */
    @Test
    void testToStringContainsId() {
        Notification n = new Notification("Message", "notif3");
        assertTrue(n.toString().contains("notif3"));
    }
}
