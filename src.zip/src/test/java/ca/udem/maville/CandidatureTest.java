package ca.udem.maville;

import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.Calendar;

import ca.udem.maville.client.Candidature;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 
 * Vérifie l’intégrité des données saisies dans une candidature, notamment :
 * - l’enregistrement correct des champs,
 * - la validité de temps des dates,
 * - la non-nullité de la soumission.
 */
public class CandidatureTest {

    // Méthode utilitaire pour ajouter des jours à une date
    private Date addDays(Date date, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days);
        return cal.getTime();
    }

    /**
     * Test 1 — Création valide :
     * Vérifie que la candidature est bien construite et contient les bons champs.
     * Résultat attendu : toutes les valeurs passées sont bien retrouvées.
     */
    @Test
    public void testCreationCandidatureValide() {
        Date dateDebut = new Date();
        Date dateFin = addDays(dateDebut, 10);
        Candidature c = new Candidature(
            "cand123", "Rue A", "NEQ999999", "prest123", "Nom Prestataire",
            "fiche123", "Projet éclairage", "Description",
            "Installation", dateDebut, dateFin, 15000.0, "Verdun"
        );

        assertEquals("Projet éclairage", c.getTitreProjet());
        assertEquals("Verdun", c.getQuartier());
        assertEquals("NEQ999999", c.getNumeroEntreprise());
        assertNotNull(c.getDateSoumission());
    }

    /**
     * Test 2 — Vérification des dates :
     * Vérifie que la date de fin est bien postérieure à la date de début.
     * Résultat attendu : dateFin > dateDebut.
     */
    @Test
    public void testDatesLogiques() {
        Date dateDebut = new Date();
        Date dateFin = addDays(dateDebut, 5);
        assertTrue(dateFin.after(dateDebut));
    }

    /**
     * Test 3 — toString non nul :
     * Vérifie que la méthode toString ne retourne pas null.
     * Résultat attendu : chaîne non nulle.
     */
    @Test
    public void testAffichageTexte() {
        Date dateDebut = new Date();
        Date dateFin = addDays(dateDebut, 10);
        Candidature c = new Candidature(
            "id", "Rue X", "NEQ123", "p", "Prestataire Inc",
            "fiche", "Titre", "desc", "Type", dateDebut, dateFin, 10000.0, "Rosemont"
        );
        assertNotNull(c.toString());
    }
}
