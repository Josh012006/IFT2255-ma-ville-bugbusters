package ca.udem.maville;

import ca.udem.maville.client.Projet;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class ProjetTest {

    /**
     * Vérifie que le changement de statut invalide déclenche une exception.
     * Résultat attendu : IllegalArgumentException.
     */
    /**
 * Test — Transition de statut invalide :
 * Vérifie qu'une exception est lancée si on tente de changer vers un statut invalide.
 * Résultat attendu : IllegalArgumentException.
 */
@Test
void testStatutTransition() {
    Projet p = new Projet(
        "P001",
        "Réparation",
        "Rue Ontario",
        "Réparation complète",
        "Voirie",
        new Date(),
        new Date(),
        "F123",
        "P001",
        "Entreprise Inc.",
        "Plateau",
        10000.0,
        2
    );

    assertThrows(IllegalArgumentException.class, () -> {
        p.setStatut("Inexistant"); // statut supposé invalide
    });
}



    /**
     * Vérifie que le projet peut être affiché sans erreur.
     * Résultat attendu : pas d'exception à l'appel de toString().
     */
    @Test
    public void testAjoutFiche() {
        Projet p = new Projet("P002", "Travaux", "Rue Z", "Desc", "Voirie", new Date(), new Date(), "", "", "", "Ahuntsic", 1000, 2);
        assertDoesNotThrow(() -> {
            p.toString();
        });
    }

    /**
     * Vérifie que le statut par défaut d’un projet est "enCours".
     * Résultat attendu : getStatut() == "enCours".
     */
    @Test
    public void testProjetSansFicheEstVide() {
        Projet p = new Projet("P003", "Vide", "Rue A", "Desc", "Éclairage", new Date(), new Date(), "", "", "", "Hochelaga", 0, 0);
        assertEquals("enCours", p.getStatut());
    }
}
