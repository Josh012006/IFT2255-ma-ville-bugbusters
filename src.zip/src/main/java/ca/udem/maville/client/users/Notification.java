package ca.udem.maville.client.users;

import java.util.ArrayList;
import java.util.Date;

public class Notification {
    private String id;
    private String message;
    private Date dateNotification;
    private ArrayList<String> signalements = new ArrayList<>();
    private ArrayList<Notification> notifications = new ArrayList<>();


    public Notification(String message, String id) {
        this.id = id;
        this.message = message;
        this.dateNotification = new Date();
    }

    public String getID() { return id; }

    public String getMessage() { return message; }

    public Date getDateNotification() { return dateNotification; }

    

    @Override
    public String toString() {
        return "Notification{" +
                "id='" + id + '\'' +
                ", message='" + message + '\'' +
                ", dateNotification=" + dateNotification +
                '}';
    }
}
