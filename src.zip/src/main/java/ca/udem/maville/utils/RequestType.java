package ca.udem.maville.utils;

public enum RequestType {
    GET,
    POST,
    PUT,
    PATCH,
    DELETE
}
